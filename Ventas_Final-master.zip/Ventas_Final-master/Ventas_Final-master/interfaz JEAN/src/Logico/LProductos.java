/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logico;

import Datos.DProductos;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import ventanas.Conexion;

/**
 *
 * @author MASTER
 */
public class LProductos {
    private Conexion mysql=new Conexion();
    private Connection cn=mysql.Conectar();
    private String sSQL="";
    
    DProductos l=new DProductos();
    
    public DefaultTableModel mostrar(String busca){
        DefaultTableModel modelo;
        
        String [] título={"Código Producto","Producto", "Descripción", "Stock", "Fecha de Entrega"};//Para que se cambie en la columna de las tablas
        String [] registro=new String [5];
        
        modelo = new DefaultTableModel(null,título);
        sSQL="select *from PRODUCTOS where NOM_PRODUCTO like '%"+busca+"%' order by COD_PRODUCTO ";
        
        try {
            Statement st=cn.createStatement();
            ResultSet rs=st.executeQuery(sSQL);
            
            while(rs.next()){
                registro[0]=rs.getString("COD_PRODUCTO");
                registro[1]=rs.getString("NOM_PRODUCTO");
                registro[2]=rs.getString("DESCR_PRODUCTO");
                registro[3]=rs.getString("STOCK");
                registro[4]=rs.getString("FECHA_ENTREGA");
                modelo.addRow(registro);
                
            }
            return modelo;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
}

package ventanas;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class RegistroTratamientoNutri extends javax.swing.JFrame {

    String fechatrata = "";
    String codptrata = "";
    HistorialNutricional hn = new HistorialNutricional();
    String nomtrata = hn.nomtrata;
    MetodoComunes metodoscomunes = new MetodoComunes();

    public RegistroTratamientoNutri() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("ASENUT - Registro Tratamiento Nutricional");      
        this.setIconImage(new ImageIcon(getClass().getResource("/imagenes/logoASENUTbarra.PNG")).getImage());

        metodoscomunes.SoloNumeros(txtPeso);
        metodoscomunes.SoloLetras(txtTratamiento);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtFechaRegistroPeso = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtCedula = new javax.swing.JTextField();
        txtPeso = new javax.swing.JTextField();
        txtTratamiento = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtObservaciones = new javax.swing.JTextArea();
        jLabel6 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        btnGuardar = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenu1 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtFechaRegistroPeso.setDateFormatString("yyyy-MM-dd");
        getContentPane().add(txtFechaRegistroPeso, new org.netbeans.lib.awtextra.AbsoluteConstraints(423, 11, 130, -1));

        jLabel1.setText("Cedula :");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 11, -1, 20));

        jLabel2.setText("Fecha :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 10, -1, 20));

        jLabel3.setText("Peso :");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 49, 38, 20));

        jLabel4.setText("Tratamiento :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 87, -1, 20));

        jLabel5.setText("Observaciones :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 125, -1, 20));

        txtCedula.setEditable(false);
        getContentPane().add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 11, 110, -1));
        getContentPane().add(txtPeso, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 49, 110, -1));
        getContentPane().add(txtTratamiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 87, 110, -1));

        txtObservaciones.setColumns(20);
        txtObservaciones.setRows(5);
        jScrollPane1.setViewportView(txtObservaciones);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 125, 447, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setText("2017-01-25");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 30, -1, -1));

        jLabel52.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jLabel52.setPreferredSize(new java.awt.Dimension(650, 427));
        getContentPane().add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 580, 250));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Save.png"))); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGuardarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnGuardar);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        jMenu2.setText("Regresar");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/minimize-icon-17_2.png"))); // NOI18N
        jMenu1.setText("Minimizar");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGuardarMouseClicked
        //Guardar
        PreparedStatement cmd;
        ResultSet rs;
        Conexion.Conectar();
        int cont = 0;

        //////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////REGISTRO TRATAMIENTO////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////
        String cedula = txtCedula.getText();
        String peso = txtPeso.getText();
        String tratamiento = txtTratamiento.getText();
        String observaciones = txtObservaciones.getText();

        System.out.println(nomtrata);
        System.out.println("cedula: " + cedula);
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select pt.FECHA_TRATA"
                    + "from paciente_tratamiento pt, "
                    + "peso_paciente mc"
                    + "where mc.CEDULA = pt.CEDULA"
                    + "and mc.COD_TRATAMIENTO = pt.COD_TRATAMIENTO"
                    + "and mc.CEDULA = '" + cedula + "'"
                    + "and mc.COD_TRATAMIENTO = '" + codptrata + "'");
            while (rs.next()) {
                fechatrata = rs.getString(1);
            }
        } catch (SQLException e) {

        }
        System.out.println("Fecha trata: " + fechatrata);

        String fdia = "";
        String fmes = "";
        if (txtFechaRegistroPeso.getCalendar().get(Calendar.DAY_OF_MONTH) <= 9) {
            fdia = "0" + txtFechaRegistroPeso.getCalendar().get(Calendar.DAY_OF_MONTH);
        } else {
            fdia = String.valueOf(txtFechaRegistroPeso.getCalendar().get(Calendar.DAY_OF_MONTH));
        }

        if ((txtFechaRegistroPeso.getCalendar().get(Calendar.MONTH) + 1) <= 9) {
            fmes = "0" + ((txtFechaRegistroPeso.getCalendar().get(Calendar.MONTH) + 1));
        } else {
            fmes = String.valueOf((txtFechaRegistroPeso.getCalendar().get(Calendar.MONTH) + 1));
        }
        String fechipeso = "'" + txtFechaRegistroPeso.getCalendar().get(Calendar.YEAR) + "-" + fmes + "-" + fdia + "'";

        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT * FROM PESO_PACIENTE");
            while (rs.next()) {
                cont++;
            }
            cont += 1;
            System.out.println("("
                    + "'" + cont + "'," + fechatrata + ",'" + cedula + "','" + codptrata + "'," + fechipeso + ",'" + peso + "','" + tratamiento + "','" + observaciones + "')");
            //'3',''2017-01-29'','0802502948','1','2017-01-31','51','MIM','IMIN'
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO PESO_PACIENTE VALUES "
                    + "('" + cont + "',"
                    + fechatrata + ",'"
                    + cedula + "','"
                    + codptrata + "',"
                    + fechipeso + ", '"
                    + peso + "','"
                    + tratamiento + "','"
                    + observaciones + "')");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "\nNo se ingreso Registro");
            System.out.println(e);
        }
        vaciar();
        HistorialNutricional hn = new HistorialNutricional();
        hn.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnGuardarMouseClicked

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        // TODO add your handling code here:
        TratamientoNutricional dg = new TratamientoNutricional();
        dg.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenu2MouseClicked

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
        ResultSet rs;
        fechatrata = hn.fecha;
        txtCedula.setText(HistorialNutricional.cedulacorporal);

        System.out.println("cedula: " + txtCedula.getText());
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_TRATAMIENTO FROM TIPO_TRATAMIENTO WHERE NOM_TRATA = " + nomtrata);
            while (rs.next()) {
                codptrata = rs.getString(1);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se encotró el tratamiento");
        }

        System.out.println("codigo tratamiento: " + codptrata);
        System.out.println("nombre tratamiento: " + nomtrata);
        System.out.println("Fecha trata: " + fechatrata);

    }//GEN-LAST:event_formWindowActivated

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        this.setExtendedState(ICONIFIED);
    }//GEN-LAST:event_jMenu1MouseClicked

    public void vaciar() {
        txtObservaciones.setText("");
        txtPeso.setText("");
        txtTratamiento.setText("");
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroTratamientoNutri.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroTratamientoNutri.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroTratamientoNutri.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroTratamientoNutri.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroTratamientoNutri().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu btnGuardar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtCedula;
    private com.toedter.calendar.JDateChooser txtFechaRegistroPeso;
    private javax.swing.JTextArea txtObservaciones;
    private javax.swing.JTextField txtPeso;
    private javax.swing.JTextField txtTratamiento;
    // End of variables declaration//GEN-END:variables
}

package ventanas;

import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class RegistroProductos extends javax.swing.JFrame {

    public void vaciar() {
        txtCodProd.setText("");
        txtNomProd.setText("");
        txtCantProd.setText("");
        txtDescripcionProd.setText("");
        dchoFecha.setDateFormatString("");
        //txtFechEnt.setText("");
    }

    public RegistroProductos() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("ASENUT - Registro Productos");      
        this.setIconImage(new ImageIcon(getClass().getResource("/imagenes/logoASENUTbarra.PNG")).getImage());
        
        SoloLetras(txtNomProd);
        SoloLetras(txtDescripcionProd);
        SoloNumeros(txtCantProd);
        
        LimitaCaracteres(txtNomProd,300);
        LimitaCaracteres(txtDescripcionProd,200);
        LimitaCaracteres(txtCantProd,20);
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtNomProd = new javax.swing.JTextField();
        txtCodProd = new javax.swing.JTextField();
        txtDescripcionProd = new javax.swing.JTextField();
        txtCantProd = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        dchoFecha = new com.toedter.calendar.JDateChooser();
        jMenuBar1 = new javax.swing.JMenuBar();
        btnGuardar = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenu1 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setText("Nombre Del Producto:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, -1, 20));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setText("Código Del Producto:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, -1, 20));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setText("Descripción:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 144, -1, 20));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setText("Cantidad:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 200, -1, 30));
        getContentPane().add(txtNomProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 80, 200, 30));

        txtCodProd.setEditable(false);
        getContentPane().add(txtCodProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 30, 200, 30));
        getContentPane().add(txtDescripcionProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 140, 200, 30));
        getContentPane().add(txtCantProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 200, 200, 30));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setText("Fecha:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, 50, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 460, 310));
        getContentPane().add(dchoFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(174, 252, 190, 30));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Save.png"))); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGuardarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnGuardar);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        jMenu2.setText("Regresar");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/minimize-icon-17_2.png"))); // NOI18N
        jMenu1.setText("Minimizar");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void LimitaCaracteres(JTextField a, int lim)
    {
        a.addKeyListener(new KeyListener() {
           @Override
            public void keyTyped(KeyEvent ke) {
              char c  = ke.getKeyChar();
              if( a.getText().length() == lim )
              {               
                ///getToolKit().beep();
                Toolkit.getDefaultToolkit().beep();
                ke.consume();
                
              }                              
            }
                
           @Override
            public void keyPressed(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

           @Override
            public void keyReleased(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }           
      });
    }
    
    public void SoloLetras(JTextField a)
    {
        a.addKeyListener (new KeyListener() {
           @Override
            public void keyTyped(KeyEvent ke) {
              char c  = ke.getKeyChar();
              if(Character.isDigit(c))
              {               
                ///getToolKit().beep();
                Toolkit.getDefaultToolkit().beep();
                ke.consume();
                JOptionPane.showMessageDialog(null, "INGRESE LETRAS");
                
                //no tomo encuenta caracteres especiales por evitar conflictos en la BDD
                
              }else if( (int)ke.getKeyChar() > 32 && (int)ke.getKeyChar() <= 47 
                      || (int)ke.getKeyChar() >= 58 && (int)ke.getKeyChar() <= 64
                      || (int)ke.getKeyChar() >= 91 && (int)ke.getKeyChar() <= 96 
                      || (int)ke.getKeyChar() >= 123 && (int)ke.getKeyChar() <= 225 ){
                  
                                Toolkit.getDefaultToolkit().beep();
                                ke.consume();
                                JOptionPane.showMessageDialog(null, "INGRESE LETRAS!");
              }               
            }
                
            // estos dos metodos sobreescriben lo de la calse padre para mejorarla 
           @Override
            public void keyPressed(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

           @Override
            public void keyReleased(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }           
      });
    } 
    
    public void SoloNumeros(JTextField a)
    {
        a.addKeyListener(new KeyListener() {
           @Override
            public void keyTyped(KeyEvent ke) {
              char c  = ke.getKeyChar();
              if(Character.isLetter(c))
              {               
                ///getToolKit().beep();
                Toolkit.getDefaultToolkit().beep();
                ke.consume();
                JOptionPane.showMessageDialog(null, "INGRESE NUMEROS!");
                
              }else if( (int)ke.getKeyChar() > 32 && (int)ke.getKeyChar() <= 47 
                      || (int)ke.getKeyChar() >= 58 && (int)ke.getKeyChar() <= 64
                      || (int)ke.getKeyChar() >= 91 && (int)ke.getKeyChar() <= 96 
                      || (int)ke.getKeyChar() >= 123 && (int)ke.getKeyChar() <= 225 ){
                  
                                Toolkit.getDefaultToolkit().beep();
                                ke.consume();
                                JOptionPane.showMessageDialog(null, "INGRESE NUMEROS");
              }                               
            }
                
            // estos dos metodos sobreescriben lo de la calse padre para mejorarla 
           @Override
            public void keyPressed(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

           @Override
            public void keyReleased(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }           
      });
    } 
    
    
    
    
    
    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        // TODO add your handling code here:
        Productos dg = new Productos();
        dg.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenu2MouseClicked

    private void btnGuardarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGuardarMouseClicked
        // INFRESO PRODUCTO
           
        PreparedStatement cmd;  
        ResultSet rs;
      

        if( txtNomProd.getText().isEmpty() ){
            
            JOptionPane.showMessageDialog(null, "Ingrese cedula","Error!",JOptionPane.ERROR_MESSAGE);
            
        }else if ( txtDescripcionProd.getText().isEmpty() ){
            
            JOptionPane.showMessageDialog(null, "Ingrese Nombre","Error!",JOptionPane.ERROR_MESSAGE);
            
        }else if( txtCantProd.getText().isEmpty() ){
            
            JOptionPane.showMessageDialog(null, "Ingrese Apellido","Error!",JOptionPane.ERROR_MESSAGE);
            
        }else if( JOptionPane.showConfirmDialog(null,"Guardar datos","Confirmar",1) == 0 ){
            
                                //ingresos

             String cod = "'" + txtCodProd.getText() + "'";
             String nom = "'" + txtNomProd.getText() + "'";
             String desc = "'" + txtDescripcionProd.getText() + "'";
             String cant = "'" + txtCantProd.getText() + "'";
             //String fech = "'" + txtFechEnt.getText() + "'";

                                 //fecha

            int anio = dchoFecha.getCalendar().get( Calendar.YEAR );
            int mes = dchoFecha.getCalendar().get( Calendar.MONTH );
            int dia = dchoFecha.getCalendar().get( Calendar.DAY_OF_MONTH );
            String fecha1 = anio+"-"+(mes+1)+"-"+dia;
            String fech = "'" + fecha1 + "'";   
        
        try {
            cmd = ventanas.Conexion.link.prepareStatement("insert into PRODUCTOS values (" + cod + "," + nom + "," + desc + "," + cant + "," + fech + ")");
            cmd.execute();
            JOptionPane.showMessageDialog(null, "Ingresado con éxito");
            vaciar();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo realizar el ingreso\n" + e);
        }

        int ingresar = JOptionPane.showConfirmDialog(null, "¿Desea ingresar otro producto?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (ingresar != 0) {
            this.setVisible(false);
            Productos pd = new Productos();
            pd.setVisible(true);
        }

        }    

    }//GEN-LAST:event_btnGuardarMouseClicked

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
        ResultSet rs;
        int cont = 0, contb = 0;
        String cod = "";
        String codigbase = "";

        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_PRODUCTO FROM PRODUCTOS");
            while (rs.next()) {
                codigbase = rs.getString(1);
                contb++;
            }
            if (contb == 0) {
                cont = 1;
            } else {
                cont = Integer.parseInt(codigbase);
                cont += 1;
            }

            cod = String.valueOf(cont);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

        //int codigo = Integer.parseInt(txtCodigo.getText());
        txtCodProd.setText(cod);
    }//GEN-LAST:event_formWindowActivated

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        this.setExtendedState(ICONIFIED);
    }//GEN-LAST:event_jMenu1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroProductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu btnGuardar;
    private com.toedter.calendar.JDateChooser dchoFecha;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JTextField txtCantProd;
    private javax.swing.JTextField txtCodProd;
    private javax.swing.JTextField txtDescripcionProd;
    private javax.swing.JTextField txtNomProd;
    // End of variables declaration//GEN-END:variables
}
